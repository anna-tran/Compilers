% abc /*
/* %abc */
/* */
aff
*/

var i:int;

begin
end
