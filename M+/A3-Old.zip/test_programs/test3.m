/* this is a comment */
% this is also a comment
% /* this is a nested comment

var x:int;
begin
    x := 2;
    if (x > 1)
        then print(x)
    else x := 1;
end
