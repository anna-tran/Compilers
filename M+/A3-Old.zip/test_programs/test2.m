var x[2]:int;      
begin
    read x[0]; 
    x[1] := 3;
    print (x[0]);
end
